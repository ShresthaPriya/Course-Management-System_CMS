package javaapplication2;

import loginsignup.LoginForm;


public class JavaApplication2 {

    public static void main(String[] args) {
        LoginForm loginForm = new LoginForm();
        loginForm.setLocationRelativeTo(null);
        loginForm.setVisible(true);
    }
    
}
